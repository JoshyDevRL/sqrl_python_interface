# sqrl_python_interface
A python package that bridges the gap between the SQRL-TournamentRunner and various rocket league python bots
